#include "yolo_segmentation.h"
#include <QFileDialog>
#include <QImage>
#include <QPixmap>

yolo_segmentation::yolo_segmentation(QWidget* parent)
    : QMainWindow(parent)
    , ui(new Ui::yolo_segmentation)                   // �� new һ��
    , engine_(new YoloSeg("C:/Users/31268/Desktop/qt_yolo_cpp/yolo_segmentation/model/yolov8m-seg.onnx", 640, 640))
{
    ui->setupUi(this);                                // �� �� -> ������ .
}

yolo_segmentation::~yolo_segmentation()
{
    delete engine_;
    delete ui;                                        
}

void yolo_segmentation::on_btnRun_clicked()
{
    // 1. ��ͼƬ
    QString file = QFileDialog::getOpenFileName(this, "ѡ��ͼƬ", "", "Images (*.jpg *.png)");
    if (file.isEmpty()) return;
    cv::Mat img = cv::imread(file.toStdString());
    if (img.empty()) return;

    // 2. ����
    auto dets = engine_->infer(img);
    qDebug() << "got" << dets.size() << "detections";
    qDebug() << "total detected masks =" << dets.size();

    cv::RNG rng(12345); // �����ɫ������
    cv::Mat overlay = img.clone();
    const auto classNames = engine_->getClassNames();

    // 3. ��������Ŀ�꣺���Ʋ�ɫ��Ĥ + �߿� + ��ǩ
    for (const auto& d : dets) {
        if (d.mask.empty() || cv::countNonZero(d.mask) == 0)
            continue;

        cv::Scalar color(255, 0, 0); // ��ɫ

        // mask ������ɫ
        overlay.setTo(color, d.mask);

        // �߿�
        cv::rectangle(img, d.box, color, 2);

        // ����� + ����
        std::string label = classNames[d.class_id] + cv::format(" %.2f", d.score);
        int baseline = 0;
        cv::Size textSize = cv::getTextSize(label, cv::FONT_HERSHEY_SIMPLEX, 0.5, 1, &baseline);

        // �����ı�������λ�ã���ֹ����ͼƬ�߽磩
        cv::Point textOrg = d.box.tl();
        textOrg.y = std::max(textOrg.y, textSize.height + 4);

        // �������ο򣨰׵ף�
        cv::Rect textBg(textOrg.x, textOrg.y - textSize.height - 4, textSize.width + 4, textSize.height + 4);
        cv::rectangle(img, textBg, cv::Scalar(255, 255, 255), cv::FILLED);

        // ���ֻ��ƣ����֣�
        cv::putText(img, label, textOrg, cv::FONT_HERSHEY_SIMPLEX, 0.5, cv::Scalar(0, 0, 0), 1);
    }

    // 4. ��� mask ��ԭͼ
    cv::addWeighted(overlay, 0.5, img, 0.5, 0, img);

    // 5. ��ʾͼ�� Qt
    cv::Mat rgb;
    cv::cvtColor(img, rgb, cv::COLOR_BGR2RGB);
    QImage qimg(rgb.data, rgb.cols, rgb.rows, rgb.step, QImage::Format_RGB888);
    ui->disResult->setPixmap(QPixmap::fromImage(qimg).scaled(
        ui->disResult->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
}