#pragma once
#include <opencv2/opencv.hpp>
#include <QDebug>
#include <vector>
#include <string>

struct Detection {
    cv::Rect box;
    int class_id;
    float score;
    cv::Mat coef;
    cv::Mat mask;
};

class YoloSeg {
public:
    YoloSeg(const std::string& modelPath, int inputW = 640, int inputH = 640);
    std::vector<Detection> infer(const cv::Mat& frame);
    std::vector<std::string> getClassNames() const { return classNames_; }

private:
    void preprocess(const cv::Mat& frame, cv::Mat& blob);
    std::vector<Detection> postprocess(const cv::Mat& frame, const std::vector<cv::Mat>& outputs);

    cv::dnn::Net net_;
    int inputW_, inputH_;
    float confThresh_ = 0.25f;
    float nmsThresh_ = 0.5f;
    float maskThresh_ = 0.4f;
    std::vector<std::string> classNames_ = { "person", "bicycle", "car", "motorcycle", "airplane", "bus",
        "train", "truck", "boat", "traffic light", "fire hydrant", "stop sign", "parking meter", "bench", "bird",
        "cat", "dog", "horse", "sheep", "cow", "elephant", "bear", "zebra", "giraffe", "backpack", "umbrella",
        "handbag", "tie", "suitcase", "frisbee", "skis", "snowboard", "sports ball", "kite", "baseball bat",
        "baseball glove", "skateboard", "surfboard", "tennis racket", "bottle", "wine glass", "cup", "fork",
        "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange", "broccoli", "carrot", "hot dog",
        "pizza", "donut", "cake", "chair", "couch", "potted plant", "bed", "dining table", "toilet", "tv",
        "laptop", "mouse", "remote", "keyboard", "cell phone", "microwave", "oven", "toaster", "sink",
        "refrigerator", "book", "clock", "vase", "scissors", "teddy bear", "hair drier", "toothbrush" };
};