#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_yolo_detection.h"
#include"inference.h"

class yolo_detection : public QMainWindow
{
    Q_OBJECT

public:
    yolo_detection(QWidget *parent = nullptr);
    ~yolo_detection();

private:
    Ui::yolo_detectionClass ui;
    Inference* pInf_ { nullptr };
};
