/********************************************************************************
** Form generated from reading UI file 'yolo_segmentation.ui'
**
** Created by: Qt User Interface Compiler version 6.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_YOLO_SEGMENTATION_H
#define UI_YOLO_SEGMENTATION_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_yolo_segmentation
{
public:
    QWidget *centralWidget;
    QLabel *disResult;
    QPushButton *btnRun;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *yolo_segmentation)
    {
        if (yolo_segmentation->objectName().isEmpty())
            yolo_segmentation->setObjectName("yolo_segmentation");
        yolo_segmentation->resize(344, 408);
        centralWidget = new QWidget(yolo_segmentation);
        centralWidget->setObjectName("centralWidget");
        disResult = new QLabel(centralWidget);
        disResult->setObjectName("disResult");
        disResult->setGeometry(QRect(0, 0, 341, 321));
        disResult->setFrameShape(QFrame::Shape::Box);
        btnRun = new QPushButton(centralWidget);
        btnRun->setObjectName("btnRun");
        btnRun->setGeometry(QRect(110, 330, 111, 24));
        yolo_segmentation->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(yolo_segmentation);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 344, 21));
        yolo_segmentation->setMenuBar(menuBar);
        mainToolBar = new QToolBar(yolo_segmentation);
        mainToolBar->setObjectName("mainToolBar");
        yolo_segmentation->addToolBar(Qt::ToolBarArea::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(yolo_segmentation);
        statusBar->setObjectName("statusBar");
        yolo_segmentation->setStatusBar(statusBar);

        retranslateUi(yolo_segmentation);

        QMetaObject::connectSlotsByName(yolo_segmentation);
    } // setupUi

    void retranslateUi(QMainWindow *yolo_segmentation)
    {
        yolo_segmentation->setWindowTitle(QCoreApplication::translate("yolo_segmentation", "yolo_segmentation", nullptr));
        disResult->setText(QCoreApplication::translate("yolo_segmentation", "TextLabel", nullptr));
        btnRun->setText(QCoreApplication::translate("yolo_segmentation", "open image", nullptr));
    } // retranslateUi

};

namespace Ui {
    class yolo_segmentation: public Ui_yolo_segmentation {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_YOLO_SEGMENTATION_H
