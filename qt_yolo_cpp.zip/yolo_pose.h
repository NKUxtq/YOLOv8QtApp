#pragma once
#include <QMainWindow>
#include "ui_yolo_pose.h"
#include "inference_pose.h"

class yolo_pose : public QMainWindow {
    Q_OBJECT
public:
    yolo_pose(QWidget* parent = nullptr);
    ~yolo_pose();

private slots:
    void on_btnRun_clicked();

private:
    Ui::yolo_pose* ui;
    PoseEstimator* est;
};
