#include "inference_seg.h"
#include <QtWidgets/QMainWindow>
#include "ui_yolo_segmentation.h"

class yolo_segmentation : public QMainWindow
{
    Q_OBJECT
public:
    yolo_segmentation(QWidget* parent = nullptr);
    ~yolo_segmentation();

private slots:
    void on_btnRun_clicked();    // �����ť��������

private:
    Ui::yolo_segmentation *ui;
    YoloSeg* engine_;
};