#include "yolo_segmentation.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    yolo_segmentation w;
    w.show();
    return a.exec();
}
