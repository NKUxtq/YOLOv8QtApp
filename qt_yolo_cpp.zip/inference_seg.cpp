#include "inference_seg.h"
#include <random>

YoloSeg::YoloSeg(const std::string& modelPath, int inputW, int inputH)
    : inputW_(inputW), inputH_(inputH) {
    net_ = cv::dnn::readNetFromONNX(modelPath);
    net_.setPreferableBackend(cv::dnn::DNN_BACKEND_OPENCV);
    net_.setPreferableTarget(cv::dnn::DNN_TARGET_CPU);
}

void YoloSeg::preprocess(const cv::Mat& frame, cv::Mat& blob) {
    cv::Mat resized;
    cv::resize(frame, resized, cv::Size(inputW_, inputH_));
    cv::dnn::blobFromImage(resized, blob, 1 / 255.0, cv::Size(), cv::Scalar(), true, false);
}

std::vector<Detection> YoloSeg::infer(const cv::Mat& frame) {
    cv::Mat blob;
    preprocess(frame, blob);
    net_.setInput(blob);
    std::vector<cv::Mat> outputs;
    net_.forward(outputs, net_.getUnconnectedOutLayersNames());
    return postprocess(frame, outputs);
}

std::vector<Detection> YoloSeg::postprocess(const cv::Mat& frame, const std::vector<cv::Mat>& outputs) {
    const cv::Mat& props = outputs[0];
    const cv::Mat& proto = outputs[1];
    int featDim = props.size[1];
    int numProps = props.size[2];
    int maskDim = proto.size[1];
    int H = proto.size[2];
    int W = proto.size[3];
    int numCls = featDim - 4 - maskDim;

    std::vector<cv::Rect> allBoxes;
    std::vector<float> allScores;
    std::vector<int> allClassIds;
    std::vector<cv::Mat> allCoefs;

    for (int i = 0; i < numProps; ++i) {
        float raw_x = props.at<float>(0, 0, i);
        float raw_y = props.at<float>(0, 1, i);
        float raw_w = props.at<float>(0, 2, i);
        float raw_h = props.at<float>(0, 3, i);

        float cx = (1.f / (1 + exp(-raw_x))) * 2 - 0.5f;
        float cy = (1.f / (1 + exp(-raw_y))) * 2 - 0.5f;
        float w = pow((1.f / (1 + exp(-raw_w))) * 2, 2);
        float h = pow((1.f / (1 + exp(-raw_h))) * 2, 2);

        cx *= inputW_;
        cy *= inputH_;
        w *= inputW_;
        h *= inputH_;

        int bestClass = 0;
        float bestScore = props.at<float>(0, 4, i);
        for (int c = 1; c < numCls; ++c) {
            float score = props.at<float>(0, 4 + c, i);
            if (score > bestScore) {
                bestScore = score;
                bestClass = c;
            }
        }
        bestScore = 1.f / (1.f + exp(-bestScore));
        if (bestScore < confThresh_) continue;

        cv::Mat coef(1, maskDim, CV_32F);
        for (int j = 0; j < maskDim; ++j) {
            coef.at<float>(0, j) = props.at<float>(0, featDim - maskDim + j, i);
        }

        allBoxes.emplace_back(cv::Rect(int(cx - w / 2), int(cy - h / 2), int(w), int(h)));
        allScores.emplace_back(bestScore);
        allClassIds.emplace_back(bestClass);
        allCoefs.emplace_back(coef);
    }

    std::vector<int> keep;
    cv::dnn::NMSBoxes(allBoxes, allScores, confThresh_, nmsThresh_, keep);

    std::vector<Detection> result;
    cv::Mat proto_flat(maskDim, H * W, CV_32F, (void*)proto.ptr<float>(0));
    for (int idx : keep) {
        Detection det;
        det.box = allBoxes[idx];
        det.score = allScores[idx];
        det.class_id = allClassIds[idx];
        det.coef = allCoefs[idx];

        cv::Mat mask = det.coef * proto_flat;
        mask = mask.reshape(1, H);
        cv::exp(-mask, mask);
        mask = 1.0 / (1.0 + mask);

        cv::Mat mask_bin;
        cv::threshold(mask, mask_bin, maskThresh_, 1.0, cv::THRESH_BINARY);
        mask_bin.convertTo(mask_bin, CV_8U);

        cv::resize(mask_bin, mask_bin, frame.size(), 0, 0, cv::INTER_NEAREST);
        cv::Mat fullMask = cv::Mat::zeros(frame.size(), CV_8U);
        cv::Rect roi = det.box & cv::Rect(0, 0, frame.cols, frame.rows);
        if (roi.area() > 0)
            mask_bin(roi).copyTo(fullMask(roi));

        det.mask = fullMask;
        result.emplace_back(det);
    }
    return result;
}