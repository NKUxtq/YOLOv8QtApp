#include <QApplication>
#include "yolo_pose.h"

int main(int argc, char* argv[]) {
    QApplication a(argc, argv);
    yolo_pose w;
    w.show();
    return a.exec();
}