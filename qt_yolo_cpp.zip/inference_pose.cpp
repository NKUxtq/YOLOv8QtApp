#define _SILENCE_CXX17_CODECVT_HEADER_DEPRECATION_WARNING
#include "inference_pose.h"
#include <codecvt>
#include <locale>
#include <numeric>

PoseEstimator::PoseEstimator(const std::string& modelPath, int inputW, int inputH)
    : env_(ORT_LOGGING_LEVEL_WARNING, "pose"), inputW_(inputW), inputH_(inputH),
    memoryInfo_(Ort::MemoryInfo::CreateCpu(OrtAllocatorType::OrtDeviceAllocator, OrtMemTypeDefault))
{
    sessionOptions_.SetIntraOpNumThreads(1);
    sessionOptions_.SetGraphOptimizationLevel(GraphOptimizationLevel::ORT_ENABLE_ALL);
    OrtCUDAProviderOptions cuda_options{};
    cuda_options.device_id = 0;
    sessionOptions_.AppendExecutionProvider_CUDA(cuda_options);

    std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
    std::wstring wpath = converter.from_bytes(modelPath);
    session_ = std::make_unique<Ort::Session>(env_, wpath.c_str(), sessionOptions_);

    Ort::AllocatorWithDefaultOptions allocator;
    auto in_name = session_->GetInputNameAllocated(0, allocator);
    auto out_name = session_->GetOutputNameAllocated(0, allocator);
    inputNames_.push_back(in_name.get());
    outputNames_.push_back(out_name.get());
}

std::vector<PoseDetection> PoseEstimator::infer(const cv::Mat& image) {
    // 1. �̶��ߴ����룺ֱ�� resize �� 640��640
    cv::Mat resized;
    cv::resize(image, resized, cv::Size(inputW_, inputH_));

    // 2. ��һ����ת RGB
    cv::Mat blob;
    resized.convertTo(blob, CV_32F, 1.0f / 255.0f);
    cv::cvtColor(blob, blob, cv::COLOR_BGR2RGB);

    // 3. HWC -> CHW
    std::vector<float> inputTensorValues(inputW_ * inputH_ * 3);
    int idx = 0;
    for (int c = 0; c < 3; ++c)
        for (int h = 0; h < inputH_; ++h)
            for (int w = 0; w < inputW_; ++w)
                inputTensorValues[idx++] = blob.at<cv::Vec3f>(h, w)[c];

    std::array<int64_t, 4> shape{ 1, 3, inputH_, inputW_ };
    auto inputTensor = Ort::Value::CreateTensor<float>(
        memoryInfo_, inputTensorValues.data(), inputTensorValues.size(), shape.data(), shape.size());

    // 4. ǰ������
    auto outputs = session_->Run(
        Ort::RunOptions{ nullptr }, inputNames_.data(), &inputTensor, 1,
        outputNames_.data(), 1);

    float* out_data = outputs[0].GetTensorMutableData<float>();
    auto out_shape = outputs[0].GetTensorTypeAndShapeInfo().GetShape();
    int N = out_shape[1], C = out_shape[2];
    std::vector<PoseDetection> results;

    // 5. ����ÿ�����
    for (int i = 0; i < N; ++i) {
        float* det = out_data + i * C;
        float score = det[4];
        if (score < confThresh_) continue;

        // ����ģ�����Ϊ��һ����������Ϳ���
        float cx = det[0], cy = det[1];
        float w = det[2], h = det[3];
        float x1 = (cx - w / 2) * inputW_;
        float y1 = (cy - h / 2) * inputH_;
        float x2 = (cx + w / 2) * inputW_;
        float y2 = (cy + h / 2) * inputH_;

        PoseDetection pd;
        pd.box = cv::Rect(cv::Point(int(x1), int(y1)), cv::Point(int(x2), int(y2)));

        // 17 ���ؼ���
        for (int j = 0; j < 17; ++j) {
            float kx_norm = det[5 + j * 3];
            float ky_norm = det[5 + j * 3 + 1];
            float ks = 1.f / (1.f + exp(-det[5 + j * 3 + 2]));

            float kx = kx_norm * inputW_;
            float ky = ky_norm * inputH_;
            if (ks > keypointThresh_) {
                pd.keypoints.emplace_back(kx, ky);
                pd.scores.emplace_back(ks);
            }
            else {
                pd.keypoints.emplace_back(0, 0);
                pd.scores.emplace_back(ks);
            }
        }
        results.push_back(pd);
    }
    return results;
}
