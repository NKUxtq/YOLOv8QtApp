#pragma once
#include <opencv2/opencv.hpp>
#include <onnxruntime_cxx_api.h>
#include <vector>
#include <memory>

struct PoseDetection {
    cv::Rect box;
    std::vector<cv::Point2f> keypoints;
    std::vector<float> scores;
};

class PoseEstimator {
public:
    PoseEstimator(const std::string& modelPath, int inputW = 640, int inputH = 640);
    std::vector<PoseDetection> infer(const cv::Mat& image);

private:
    Ort::Env env_;
    Ort::SessionOptions sessionOptions_;
    std::unique_ptr<Ort::Session> session_;
    Ort::MemoryInfo memoryInfo_;
    std::vector<const char*> inputNames_;
    std::vector<const char*> outputNames_;
    int inputW_, inputH_;
    float confThresh_ = 0.1f;
    float keypointThresh_ = 0.2f;
};


