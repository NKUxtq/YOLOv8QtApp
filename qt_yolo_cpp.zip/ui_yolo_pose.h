/********************************************************************************
** Form generated from reading UI file 'yolo_pose.ui'
**
** Created by: Qt User Interface Compiler version 6.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_YOLO_POSE_H
#define UI_YOLO_POSE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_yolo_pose
{
public:
    QWidget *centralWidget;
    QLabel *disResult;
    QPushButton *btnRun;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *yolo_pose)
    {
        if (yolo_pose->objectName().isEmpty())
            yolo_pose->setObjectName("yolo_pose");
        yolo_pose->resize(344, 408);
        centralWidget = new QWidget(yolo_pose);
        centralWidget->setObjectName("centralWidget");
        disResult = new QLabel(centralWidget);
        disResult->setObjectName("disResult");
        disResult->setGeometry(QRect(0, 0, 341, 321));
        disResult->setFrameShape(QFrame::Shape::Box);
        btnRun = new QPushButton(centralWidget);
        btnRun->setObjectName("btnRun");
        btnRun->setGeometry(QRect(110, 330, 111, 24));
        yolo_pose->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(yolo_pose);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 344, 18));
        yolo_pose->setMenuBar(menuBar);
        mainToolBar = new QToolBar(yolo_pose);
        mainToolBar->setObjectName("mainToolBar");
        yolo_pose->addToolBar(Qt::ToolBarArea::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(yolo_pose);
        statusBar->setObjectName("statusBar");
        yolo_pose->setStatusBar(statusBar);

        retranslateUi(yolo_pose);

        QMetaObject::connectSlotsByName(yolo_pose);
    } // setupUi

    void retranslateUi(QMainWindow *yolo_pose)
    {
        yolo_pose->setWindowTitle(QCoreApplication::translate("yolo_pose", "yolo_pose", nullptr));
        disResult->setText(QCoreApplication::translate("yolo_pose", "TextLabel", nullptr));
        btnRun->setText(QCoreApplication::translate("yolo_pose", "open image", nullptr));
    } // retranslateUi

};

namespace Ui {
    class yolo_pose: public Ui_yolo_pose {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_YOLO_POSE_H
