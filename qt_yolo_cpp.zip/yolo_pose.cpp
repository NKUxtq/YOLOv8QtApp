#include "yolo_pose.h"
#include <QFileDialog>
#include <QDebug>
#include <QImage>
#include <QPixmap>

yolo_pose::yolo_pose(QWidget* parent)
    : QMainWindow(parent), ui(new Ui::yolo_pose) {
    ui->setupUi(this);
    est = new PoseEstimator("model/yolov8s-pose.onnx", 640, 640);
    connect(ui->btnRun, &QPushButton::clicked, this, &yolo_pose::on_btnRun_clicked);
}

yolo_pose::~yolo_pose() {
    delete est;
    delete ui;
}

void yolo_pose::on_btnRun_clicked() {
    QString file = QFileDialog::getOpenFileName(this, "open image", "", "*.jpg *.png");
    if (file.isEmpty()) return;

    cv::Mat img = cv::imread(file.toStdString());
    if (img.empty()) { qDebug() << "load fail"; return; }
    cv::Mat frame;
    cv::resize(img, frame, cv::Size(640, 640));

    auto poses = est->infer(frame);
    for (auto& p : poses) {
        cv::rectangle(frame, p.box, cv::Scalar(255, 0, 0), 2);
        for (size_t i = 0; i < p.keypoints.size(); ++i) {
            if (p.scores[i] > 0.2f)
                cv::circle(frame, p.keypoints[i], 3, cv::Scalar(0, 255, 0), -1);
        }
    }

    cv::Mat rgb;
    cv::cvtColor(frame, rgb, cv::COLOR_BGR2RGB);
    QImage qimg(rgb.data, rgb.cols, rgb.rows, rgb.step, QImage::Format_RGB888);
    ui->disResult->setPixmap(QPixmap::fromImage(qimg));
}
