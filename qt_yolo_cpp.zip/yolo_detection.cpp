﻿#include "yolo_detection.h"
#include<QFileDialog>

cv::Mat g_QImageToCvMat(const QImage& image) {
    switch (image.format()) {
    case QImage::Format_RGB32: {
        cv::Mat mat(image.height(), image.width(), CV_8UC4, const_cast<uchar*>(image.bits()), image.bytesPerLine());
        return mat.clone();
    }
    case QImage::Format_RGB888: {
        QImage swapped = image.rgbSwapped(); // 正确交换R和B通道
        cv::Mat mat(swapped.height(), swapped.width(), CV_8UC3, const_cast<uchar*>(swapped.bits()), swapped.bytesPerLine());
        return mat.clone();
    }
    case QImage::Format_Grayscale8: {
        cv::Mat mat(image.height(), image.width(), CV_8UC1, const_cast<uchar*>(image.bits()), image.bytesPerLine());
        return mat.clone();
    }
    default:
        throw std::invalid_argument("Unsupported QImage format");
    }
}

QImage g_cvMatToQImage(const cv::Mat& mat) {
    switch (mat.type()) {
    case CV_8UC1: // 灰度图
        return QImage(mat.data, mat.cols, mat.rows, mat.step, QImage::Format_Grayscale8).copy();

    case CV_8UC3: { // 3通道BGR转RGB
        cv::Mat rgb;
        cv::cvtColor(mat, rgb, cv::COLOR_BGR2RGB); // 转换颜色空间
        // 使用转换后的rgb矩阵数据创建QImage
        return QImage(rgb.data, rgb.cols, rgb.rows, rgb.step, QImage::Format_RGB888).copy();
    }
    case CV_8UC4: // 4通道（假设为BGRA，匹配QImage的ARGB32格式）
        return QImage(mat.data, mat.cols, mat.rows, mat.step, QImage::Format_ARGB32).copy();

    default:
        qWarning("Unsupported cv::Mat format for conversion to QImage");
        return QImage();
    }
}

yolo_detection::yolo_detection(QWidget* parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
    bool runOnGPU = true;
    std::string modelPath = "C:/Users/31268/Desktop/qt_yolo_cpp/detection/model/yolo11s.onnx";
    std::string classesPath = "C:/Users/31268/Desktop/qt_yolo_cpp/detection/model/classes.txt";

    pInf_ = new Inference(modelPath, cv::Size(640, 640), classesPath, runOnGPU);

    QObject::connect(ui.btnOpenimage, &QPushButton::clicked, this, [=] {

        QString filePath = QFileDialog::getOpenFileName(this, "选择图片", "", "图像文件(*.png *.jpg *.bmp)");
        if (!filePath.isEmpty()) {
            //加载图片并显示
            QImage image(filePath);

            if (image.format() != QImage::Format_RGB888) {
                image = image.convertToFormat(QImage::Format_RGB888);
            }

            // Inference starts here...
            //cv::Mat frame = cv::imread("C:/Users/31268/Desktop/qt_yolo_cpp/detection/data/000000000036.jpg");
            cv::Mat frame = g_QImageToCvMat(image);

            std::vector<Detection> output = pInf_->runInference(frame);

            int detections = output.size();
            std::cout << "Number of detections:" << detections << std::endl;

            for (int i = 0; i < detections; ++i)
            {
                Detection detection = output[i];

                cv::Rect box = detection.box;
                cv::Scalar color = detection.color;

                // Detection box
                cv::rectangle(frame, box, color, 2);

                // Detection box text
                std::string classString = detection.className + ' ' + std::to_string(detection.confidence).substr(0, 4);
                cv::Size textSize = cv::getTextSize(classString, cv::FONT_HERSHEY_DUPLEX, 1, 2, 0);
                cv::Rect textBox(box.x, box.y - 40, textSize.width + 10, textSize.height + 20);

                cv::rectangle(frame, textBox, color, cv::FILLED);
                cv::putText(frame, classString, cv::Point(box.x + 5, box.y - 10), cv::FONT_HERSHEY_DUPLEX, 1, cv::Scalar(0, 0, 0), 2, 0);
            }
            // Inference ends here...

            // This is only for preview purposes
            float scale = 0.8;
            cv::resize(frame, frame, cv::Size(frame.cols * scale, frame.rows * scale));
            cv::imshow("Inference", frame);

            QImage dst = g_cvMatToQImage(frame);

            ui.dispResult->setPixmap(QPixmap::fromImage(dst));
        }

        });
}

yolo_detection::~yolo_detection()
{
    delete pInf_;
}
